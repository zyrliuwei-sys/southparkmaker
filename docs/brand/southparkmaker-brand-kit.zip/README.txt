southparkmaker / Alpine Studio brand kit

Open index.html in a modern browser to view the portable brand guidelines. The included variable fonts and SVG marks are editable. social-card-source.html is the editable 1200 x 630 share-card source. Brand tokens are in tokens.css.

Fonts: Bricolage Grotesque Variable and Manrope Variable. Their original licenses are included under fonts/. Keep those licenses with redistributed font files.

The kit contains only brand assets; no app credentials, database data, or runtime settings are included.
